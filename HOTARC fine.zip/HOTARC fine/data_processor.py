import torch
import torch.nn as nn
from typing import Dict, List, Optional, Tuple, Any, Union
import numpy as np
from dataclasses import dataclass
import logging
import threading
from queue import PriorityQueue
import time
from pathlib import Path
import json
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import IsolationForest
from sklearn.cluster import DBSCAN
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import mean_squared_error
from keras.models import Model
from keras.layers import Input, Dense
from keras.optimizers import Adam

@dataclass
class DataBatch:
    """Batch of data for processing"""
    batch_id: str
    data: Union[np.ndarray, pd.DataFrame]
    metadata: Dict[str, Any]
    processing_priority: float
    timestamp: float

@dataclass
class ProcessingResult:
    """Result of data processing"""
    batch_id: str
    processed_data: Union[np.ndarray, pd.DataFrame]
    features: Dict[str, Any]
    statistics: Dict[str, float]
    processing_time: float
    quality_score: float

class DataProcessor:
    def __init__(self):
        self.setup_logging()
        self.batch_queue = PriorityQueue()
        self.processed_batches: Dict[str, ProcessingResult] = {}
        self.feature_statistics: Dict[str, List[float]] = {}
        self.lock = threading.Lock()
        self._shutdown = False
        
        # Initialize processing thread
        self.processing_thread = threading.Thread(target=self._continuous_processing)
        self.processing_thread.daemon = True
        self.processing_thread.start()
        
        # Initialize preprocessing components
        self.standard_scaler = StandardScaler()
        self.minmax_scaler = MinMaxScaler()
        self.pca = PCA(n_components=0.95)  # Preserve 95% variance
        self.feature_selector = SelectKBest(score_func=f_classif)
        
    def setup_logging(self):
        """Setup logging configuration"""
        logging.basicConfig(
            filename='data_processor.log',
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('DataProcessor')
        
    def process_data(self, data: Union[np.ndarray, pd.DataFrame], metadata: Dict[str, Any] = None):
        """Process incoming data"""
        try:
            # Create data batch
            batch = DataBatch(
                batch_id=f"batch_{time.time()}",
                data=data,
                metadata=metadata or {},
                processing_priority=self._calculate_priority(data, metadata),
                timestamp=time.time()
            )
            
            # Queue batch for processing
            self.batch_queue.put((-batch.processing_priority, batch))
            
            self.logger.info(f"Queued batch {batch.batch_id} for processing")
            
        except Exception as e:
            self.logger.error(f"Error queueing data batch: {e}")
            
    def _calculate_priority(self, data: Union[np.ndarray, pd.DataFrame], metadata: Dict[str, Any]) -> float:
        """Calculate processing priority for a data batch"""
        try:
            priority = 1.0
            
            # Size-based priority
            if isinstance(data, np.ndarray):
                size = data.size
            else:
                size = data.size
            priority *= np.log1p(size)
            
            # Metadata-based priority
            if metadata:
                if metadata.get('urgent', False):
                    priority *= 2.0
                if metadata.get('importance', 0) > 0:
                    priority *= (1.0 + metadata['importance'])
                    
            return priority
            
        except Exception as e:
            self.logger.error(f"Error calculating priority: {e}")
            return 1.0
            
    def _continuous_processing(self):
        """Continuous data processing"""
        while not self._shutdown:
            try:
                if not self.batch_queue.empty():
                    # Get highest priority batch
                    _, batch = self.batch_queue.get()
                    
                    # Process batch
                    result = self._process_batch(batch)
                    
                    # Store result
                    if result:
                        with self.lock:
                            self.processed_batches[batch.batch_id] = result
                            self._update_statistics(result)
                            
                time.sleep(0.1)  # Small delay between batches
                
            except Exception as e:
                self.logger.error(f"Error in continuous processing: {e}")
                
    def _process_batch(self, batch: DataBatch) -> Optional[ProcessingResult]:
        """Process a single data batch"""
        try:
            start_time = time.time()
            
            # Preprocess data
            preprocessed_data = self._preprocess_data(batch.data)
            
            # Extract features
            features = self._extract_features(preprocessed_data)
            
            # Calculate statistics
            statistics = self._calculate_statistics(preprocessed_data)
            
            # Calculate quality score
            quality_score = self._assess_quality(preprocessed_data, statistics)
            
            processing_time = time.time() - start_time
            
            return ProcessingResult(
                batch_id=batch.batch_id,
                processed_data=preprocessed_data,
                features=features,
                statistics=statistics,
                processing_time=processing_time,
                quality_score=quality_score
            )
            
        except Exception as e:
            self.logger.error(f"Error processing batch {batch.batch_id}: {e}")
            return None
            
    def _preprocess_data(self, data: Union[np.ndarray, pd.DataFrame]) -> Union[np.ndarray, pd.DataFrame]:
        """Preprocess data with multiple techniques"""
        try:
            # Convert to numpy if pandas
            if isinstance(data, pd.DataFrame):
                data = data.to_numpy()
                
            # Handle missing values
            data = np.nan_to_num(data)
            
            # Standardization
            data = self.standard_scaler.fit_transform(data)
            
            # Dimensionality reduction if needed
            if data.shape[1] > 50:  # Only if many features
                data = self.pca.fit_transform(data)
                
            # Feature selection
            if data.shape[1] > 10:  # Only if enough features
                data = self.feature_selector.fit_transform(data, np.zeros(data.shape[0]))
                
            return data
            
        except Exception as e:
            self.logger.error(f"Error preprocessing data: {e}")
            return data
            
    def _extract_features(self, data: np.ndarray) -> Dict[str, Any]:
        """Extract features from preprocessed data"""
        try:
            features = {}
            
            # Basic statistical features
            features.update({
                'mean': np.mean(data, axis=0).tolist(),
                'std': np.std(data, axis=0).tolist(),
                'min': np.min(data, axis=0).tolist(),
                'max': np.max(data, axis=0).tolist()
            })
            
            # Shape features
            features.update({
                'shape': data.shape,
                'dimensionality': data.ndim,
                'size': data.size
            })
            
            # Distribution features
            features.update({
                'skewness': self._calculate_skewness(data),
                'kurtosis': self._calculate_kurtosis(data)
            })
            
            return features
            
        except Exception as e:
            self.logger.error(f"Error extracting features: {e}")
            return {}
            
    def _calculate_statistics(self, data: np.ndarray) -> Dict[str, float]:
        """Calculate detailed statistics"""
        try:
            return {
                'mean': float(np.mean(data)),
                'std': float(np.std(data)),
                'median': float(np.median(data)),
                'q1': float(np.percentile(data, 25)),
                'q3': float(np.percentile(data, 75)),
                'iqr': float(np.percentile(data, 75) - np.percentile(data, 25)),
                'missing_ratio': float(np.isnan(data).mean()),
                'unique_ratio': float(len(np.unique(data)) / data.size)
            }
        except Exception as e:
            self.logger.error(f"Error calculating statistics: {e}")
            return {}
            
    def _assess_quality(self, data: np.ndarray, statistics: Dict[str, float]) -> float:
        """Assess quality of processed data"""
        try:
            quality_score = 1.0
            
            # Penalize for missing values
            quality_score *= (1.0 - statistics.get('missing_ratio', 0))
            
            # Reward for data variability
            quality_score *= min(1.0, statistics.get('unique_ratio', 0) * 2)
            
            # Penalize for extreme outliers
            z_scores = np.abs((data - np.mean(data)) / np.std(data))
            outlier_ratio = np.mean(z_scores > 3)
            quality_score *= (1.0 - outlier_ratio)
            
            return float(quality_score)
            
        except Exception as e:
            self.logger.error(f"Error assessing quality: {e}")
            return 0.0
            
    def _calculate_skewness(self, data: np.ndarray) -> List[float]:
        """Calculate skewness for each feature"""
        try:
            return np.mean((data - np.mean(data, axis=0)) ** 3, axis=0).tolist()
        except Exception as e:
            self.logger.error(f"Error calculating skewness: {e}")
            return []
            
    def _calculate_kurtosis(self, data: np.ndarray) -> List[float]:
        """Calculate kurtosis for each feature"""
        try:
            return np.mean((data - np.mean(data, axis=0)) ** 4, axis=0).tolist()
        except Exception as e:
            self.logger.error(f"Error calculating kurtosis: {e}")
            return []
            
    def _update_statistics(self, result: ProcessingResult):
        """Update running statistics"""
        try:
            for feature, value in result.statistics.items():
                if feature not in self.feature_statistics:
                    self.feature_statistics[feature] = []
                self.feature_statistics[feature].append(value)
                
            # Keep only recent statistics
            max_history = 1000
            for feature in self.feature_statistics:
                if len(self.feature_statistics[feature]) > max_history:
                    self.feature_statistics[feature] = self.feature_statistics[feature][-max_history:]
                    
        except Exception as e:
            self.logger.error(f"Error updating statistics: {e}")
            
    def get_statistics(self) -> Dict[str, Dict[str, float]]:
        """Get current statistics summary"""
        try:
            summary = {}
            for feature, values in self.feature_statistics.items():
                summary[feature] = {
                    'mean': float(np.mean(values)),
                    'std': float(np.std(values)),
                    'min': float(np.min(values)),
                    'max': float(np.max(values)),
                    'recent': float(values[-1]) if values else 0.0
                }
            return summary
            
        except Exception as e:
            self.logger.error(f"Error getting statistics summary: {e}")
            return {}
            
    def get_batch_result(self, batch_id: str) -> Optional[ProcessingResult]:
        """Get result for a specific batch"""
        try:
            return self.processed_batches.get(batch_id)
        except Exception as e:
            self.logger.error(f"Error getting batch result: {e}")
            return None
            
    def clear_old_results(self, max_age: float = 3600):
        """Clear old processing results"""
        try:
            current_time = time.time()
            with self.lock:
                self.processed_batches = {
                    batch_id: result
                    for batch_id, result in self.processed_batches.items()
                    if current_time - float(batch_id.split('_')[1]) < max_age
                }
        except Exception as e:
            self.logger.error(f"Error clearing old results: {e}")
            
    def shutdown(self):
        """Graceful shutdown"""
        self._shutdown = True
        if hasattr(self, 'processing_thread'):
            self.processing_thread.join()

    def augment_data(self, data):
        augmented_data = self._apply_noise_injection(data)
        augmented_data = self._apply_data_warping(augmented_data)
        augmented_data = self._generate_synthetic_data(augmented_data)
        return augmented_data

    def _apply_noise_injection(self, data, noise_level=0.01):
        noise = np.random.normal(0, noise_level, data.shape)
        noisy_data = data + noise
        logging.info("Applied noise injection.")
        return noisy_data

    def _apply_data_warping(self, data, warping_factor=0.01):
        warped_data = data + warping_factor * np.sin(data)
        logging.info("Applied data warping.")
        return warped_data

    def _generate_synthetic_data(self, data, num_samples=100):
        synthetic_data = np.random.choice(data.flatten(), (num_samples, data.shape[1]))
        logging.info("Generated synthetic data.")
        return np.vstack([data, synthetic_data])

    def detect_anomalies(self, data, method='isolation_forest'):
        if method == 'isolation_forest':
            return self._detect_anomalies_isolation_forest(data)
        elif method == 'dbscan':
            return self._detect_anomalies_dbscan(data)
        elif method == 'autoencoder':
            return self._detect_anomalies_autoencoder(data)
        else:
            logging.error(f"Unknown anomaly detection method: {method}")
            return None

    def _detect_anomalies_isolation_forest(self, data):
        clf = IsolationForest(contamination=0.1)
        clf.fit(data)
        anomalies = clf.predict(data)
        anomaly_indices = np.where(anomalies == -1)[0]
        logging.info(f"Detected {len(anomaly_indices)} anomalies using Isolation Forest.")
        return anomaly_indices

    def _detect_anomalies_dbscan(self, data, eps=0.5, min_samples=5):
        scaler = StandardScaler()
        data_scaled = scaler.fit_transform(data)
        db = DBSCAN(eps=eps, min_samples=min_samples).fit(data_scaled)
        labels = db.labels_
        anomaly_indices = np.where(labels == -1)[0]
        logging.info(f"Detected {len(anomaly_indices)} anomalies using DBSCAN.")
        return anomaly_indices

    def _detect_anomalies_autoencoder(self, data, epochs=50, batch_size=32):
        input_dim = data.shape[1]
        encoding_dim = input_dim // 2

        input_layer = Input(shape=(input_dim,))
        encoded = Dense(encoding_dim, activation='relu')(input_layer)
        decoded = Dense(input_dim, activation='sigmoid')(encoded)

        autoencoder = Model(input_layer, decoded)
        autoencoder.compile(optimizer=Adam(), loss='mean_squared_error')

        autoencoder.fit(data, data, epochs=epochs, batch_size=batch_size, shuffle=True, verbose=0)
        predictions = autoencoder.predict(data)
        mse = np.mean(np.power(data - predictions, 2), axis=1)
        anomaly_indices = np.where(mse > np.percentile(mse, 95))[0]
        logging.info(f"Detected {len(anomaly_indices)} anomalies using Autoencoder.")
        return anomaly_indices