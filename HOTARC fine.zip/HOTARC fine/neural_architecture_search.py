import torch
import torch.nn as nn
from typing import Dict, List, Optional, Tuple
import numpy as np
from concurrent.futures import ThreadPoolExecutor
import threading
from queue import PriorityQueue
import time
from torch.nn import TransformerEncoderLayer, LayerNorm

class ArchitectureOptimizer:
    def __init__(self, config, performance_threshold=0.85):
        self.config = config
        self.performance_threshold = performance_threshold
        self.architecture_queue = PriorityQueue()
        self.best_architectures = []
        self.evolution_lock = threading.Lock()
        self.stop_evolution = threading.Event()
        self.generation_count = 0
        self.population_size = 30
        self.mutation_rate = 0.2
        self.crossover_rate = 0.8
        
    def start_evolution(self):
        """Start the continuous evolution process"""
        self.evolution_thread = threading.Thread(target=self._evolve_continuously)
        self.evolution_thread.start()
        
    def stop_evolution(self):
        """Safely stop the evolution process"""
        self.stop_evolution.set()
        if hasattr(self, 'evolution_thread'):
            self.evolution_thread.join()
            
    def _evolve_continuously(self):
        """Continuous evolution process with advanced genetic algorithms"""
        while not self.stop_evolution.is_set():
            try:
                with self.evolution_lock:
                    # Generate initial population if needed
                    if self.generation_count == 0:
                        population = self._generate_candidates(self.population_size)
                    else:
                        # Evolution steps
                        population = self._evolve_population()
                    
                    # Evaluate population in parallel
                    with ThreadPoolExecutor() as executor:
                        results = list(executor.map(self._evaluate_architecture, population))
                        
                    # Update best architectures
                    for arch, score in results:
                        if score > self.performance_threshold:
                            self.architecture_queue.put((-score, arch))
                            
                    # Adaptive parameter updates
                    self._adapt_parameters()
                    
                    # Prune and maintain best architectures
                    self._prune_architectures()
                    
                    self.generation_count += 1
                    
            except Exception as e:
                print(f"Error in evolution process: {e}")
                continue
                
    def _evolve_population(self) -> List[Dict]:
        """Evolve population using advanced genetic operations"""
        # Sort population by fitness
        population = []
        while not self.architecture_queue.empty():
            score, arch = self.architecture_queue.get()
            population.append((arch, -score))  # Convert back to positive score
            
        population.sort(key=lambda x: x[1], reverse=True)
        architectures = [p[0] for p in population]
        
        # Elitism: Keep best performing architectures
        new_population = architectures[:2]
        
        while len(new_population) < self.population_size:
            if np.random.random() < self.crossover_rate:
                # Crossover
                parent1, parent2 = self._select_parents(architectures)
                child = self._crossover(parent1, parent2)
            else:
                # Mutation
                parent = self._select_parents(architectures)[0]
                child = self._mutate(parent)
                
            new_population.append(child)
            
        return new_population
        
    def _select_parents(self, population: List[Dict]) -> Tuple[Dict, Dict]:
        """Tournament selection for parents"""
        tournament_size = 3
        tournament1 = np.random.choice(len(population), tournament_size, replace=False)
        tournament2 = np.random.choice(len(population), tournament_size, replace=False)
        
        parent1 = population[max(tournament1)]
        parent2 = population[max(tournament2)]
        
        return parent1, parent2
        
    def _crossover(self, parent1: Dict, parent2: Dict) -> Dict:
        """Perform crossover between two parent architectures"""
        child = {
            'layers': [],
            'activation': parent1['activation'] if np.random.random() < 0.5 else parent2['activation'],
            'optimizer': parent1['optimizer'] if np.random.random() < 0.5 else parent2['optimizer'],
            'learning_rate': (parent1['learning_rate'] + parent2['learning_rate']) / 2
        }
        
        # Layer-wise crossover
        max_layers = max(len(parent1['layers']), len(parent2['layers']))
        for i in range(max_layers):
            if i < len(parent1['layers']) and i < len(parent2['layers']):
                # Combine layer parameters
                layer = {}
                for key in parent1['layers'][i].keys():
                    layer[key] = parent1['layers'][i][key] if np.random.random() < 0.5 else parent2['layers'][i][key]
                child['layers'].append(layer)
            elif i < len(parent1['layers']):
                child['layers'].append(parent1['layers'][i].copy())
            else:
                child['layers'].append(parent2['layers'][i].copy())
                
        return child
        
    def _mutate(self, architecture: Dict) -> Dict:
        """Perform mutation on architecture"""
        mutated = architecture.copy()
        
        if np.random.random() < self.mutation_rate:
            # Mutate activation
            mutated['activation'] = self._select_activation()
            
        if np.random.random() < self.mutation_rate:
            # Mutate optimizer
            mutated['optimizer'] = self._select_optimizer()
            
        # Mutate learning rate
        if np.random.random() < self.mutation_rate:
            mutated['learning_rate'] *= np.random.uniform(0.5, 2.0)
            mutated['learning_rate'] = np.clip(mutated['learning_rate'], 1e-5, 1e-2)
            
        # Mutate layers
        mutated['layers'] = []
        for layer in architecture['layers']:
            if np.random.random() < self.mutation_rate:
                # Modify layer
                new_layer = layer.copy()
                if np.random.random() < 0.3:
                    new_layer['type'] = np.random.choice(['linear', 'conv', 'transformer'])
                new_layer['units'] = 2 ** np.random.randint(6, 11)
                new_layer['dropout'] = np.random.uniform(0.1, 0.5)
                mutated['layers'].append(new_layer)
            else:
                mutated['layers'].append(layer.copy())
                
        return mutated
        
    def _generate_candidates(self, num_candidates=10) -> List[Dict]:
        """Generate architecture candidates using advanced patterns"""
        candidates = []
        for _ in range(num_candidates):
            arch = {
                'layers': self._generate_layers(),
                'activation': self._select_activation(),
                'optimizer': self._select_optimizer(),
                'learning_rate': np.random.uniform(1e-5, 1e-2),
                'attention_heads': np.random.randint(4, 16),
                'layer_norm_eps': 1e-5,
                'dropout_rate': np.random.uniform(0.1, 0.5)
            }
            candidates.append(arch)
        return candidates
        
    def _generate_layers(self) -> List[Dict]:
        """Generate advanced layer configurations"""
        layers = []
        num_layers = np.random.randint(3, 15)  # Increased max layers
        
        # Add input processing layers
        layers.append({
            'type': 'linear',
            'units': 2 ** np.random.randint(8, 11),
            'dropout': np.random.uniform(0.1, 0.3),
            'batch_norm': True
        })
        
        # Add intermediate layers
        for i in range(num_layers - 2):
            layer_type = np.random.choice(['linear', 'conv', 'transformer'], 
                                        p=[0.3, 0.3, 0.4])  # Bias towards transformers
            
            layer = {
                'type': layer_type,
                'units': 2 ** np.random.randint(6, 12),
                'dropout': np.random.uniform(0.1, 0.5),
                'batch_norm': np.random.random() < 0.7
            }
            
            if layer_type == 'transformer':
                layer.update({
                    'num_heads': 2 ** np.random.randint(2, 4),
                    'ff_dim': 2 ** np.random.randint(8, 11),
                    'attention_dropout': np.random.uniform(0.1, 0.3)
                })
            elif layer_type == 'conv':
                layer.update({
                    'kernel_size': np.random.choice([3, 5, 7]),
                    'stride': np.random.choice([1, 2]),
                    'padding': 'same'
                })
                
            layers.append(layer)
            
        # Add output processing layer
        layers.append({
            'type': 'linear',
            'units': 2 ** np.random.randint(6, 9),
            'dropout': np.random.uniform(0.1, 0.3),
            'batch_norm': True
        })
        
        return layers
        
    def _select_activation(self) -> str:
        """Select advanced activation function"""
        return np.random.choice([
            'relu', 'gelu', 'swish', 'mish',
            'elu', 'selu', 'hardswish', 'prelu'
        ])
        
    def _select_optimizer(self) -> str:
        """Select advanced optimizer"""
        return np.random.choice([
            'adam', 'adamw', 'lion', 'sophia',
            'adafactor', 'adagrad', 'radam', 'rectified_adam'
        ])
        
    def _create_test_model(self, arch: Dict) -> nn.Module:
        """Create a test model with advanced architectures"""
        layers = []
        in_features = 784  # Example input size
        
        for layer_config in arch['layers']:
            if layer_config['type'] == 'linear':
                layers.append(nn.Linear(in_features, layer_config['units']))
                if layer_config.get('batch_norm', False):
                    layers.append(nn.BatchNorm1d(layer_config['units']))
                layers.append(self._get_activation(arch['activation']))
                layers.append(nn.Dropout(layer_config['dropout']))
                in_features = layer_config['units']
            elif layer_config['type'] == 'transformer':
                encoder_layer = TransformerEncoderLayer(
                    d_model=in_features,
                    nhead=layer_config['num_heads'],
                    dim_feedforward=layer_config['ff_dim'],
                    dropout=layer_config['attention_dropout'],
                    activation=arch['activation']
                )
                layers.append(encoder_layer)
                layers.append(LayerNorm(in_features))
                
        return nn.Sequential(*layers)
        
    def _get_activation(self, name: str) -> nn.Module:
        """Get advanced activation function"""
        activations = {
            'relu': nn.ReLU(),
            'gelu': nn.GELU(),
            'swish': nn.SiLU(),
            'mish': nn.Mish(),
            'elu': nn.ELU(),
            'selu': nn.SELU(),
            'hardswish': nn.Hardswish(),
            'prelu': nn.PReLU()
        }
        return activations.get(name, nn.ReLU())
        
    def _test_performance(self, model: nn.Module) -> float:
        """Advanced performance testing"""
        try:
            # Generate more complex test data
            batch_size = 256
            x = torch.randn(batch_size, 784)
            y = torch.randint(0, 10, (batch_size,))
            
            if torch.cuda.is_available():
                x = x.cuda()
                y = y.cuda()
                model = model.cuda()
            
            # Warm-up run
            with torch.no_grad():
                model(x)
            
            # Test forward pass speed and memory usage
            start_time = time.time()
            with torch.no_grad():
                for _ in range(5):  # Multiple forward passes
                    output = model(x)
            inference_time = (time.time() - start_time) / 5
            
            # Calculate memory usage
            memory_used = torch.cuda.max_memory_allocated() if torch.cuda.is_available() else 0
            
            # Calculate model complexity
            num_params = sum(p.numel() for p in model.parameters())
            
            # Combined score based on multiple metrics
            speed_score = 1.0 / (1.0 + inference_time)
            memory_score = 1.0 / (1.0 + memory_used / 1e9)
            complexity_score = 1.0 / (1.0 + np.log(num_params))
            
            # Weighted combination
            return 0.4 * speed_score + 0.3 * memory_score + 0.3 * complexity_score
            
        except Exception as e:
            print(f"Error in performance test: {e}")
            return 0.0
            
    def _adapt_parameters(self):
        """Adapt evolution parameters based on progress"""
        if self.generation_count > 0 and self.generation_count % 10 == 0:
            # Adjust mutation rate based on population diversity
            self.mutation_rate = min(0.4, self.mutation_rate * 1.1)
            
            # Adjust population size based on performance
            if self.architecture_queue.qsize() < 5:
                self.population_size = min(50, self.population_size + 5)
            else:
                self.population_size = max(20, self.population_size - 5)
                
    def _prune_architectures(self):
        """Maintain only the best architectures with diversity"""
        architectures = []
        while not self.architecture_queue.empty() and len(architectures) < 20:
            score, arch = self.architecture_queue.get()
            # Check for architectural diversity
            if not self._is_similar_to_existing(arch, architectures):
                architectures.append((score, arch))
                
        # Restore to queue
        for score, arch in architectures:
            self.architecture_queue.put((score, arch))
            
    def _is_similar_to_existing(self, arch: Dict, architectures: List[Tuple[float, Dict]]) -> bool:
        """Check if architecture is too similar to existing ones"""
        for _, existing_arch in architectures:
            if self._architecture_similarity(arch, existing_arch) > 0.9:
                return True
        return False
        
    def _architecture_similarity(self, arch1: Dict, arch2: Dict) -> float:
        """Calculate similarity between two architectures"""
        # Compare layer structures
        layer_sim = self._compare_layers(arch1['layers'], arch2['layers'])
        
        # Compare other parameters
        param_sim = (
            float(arch1['activation'] == arch2['activation']) +
            float(arch1['optimizer'] == arch2['optimizer']) +
            float(abs(arch1['learning_rate'] - arch2['learning_rate']) < 1e-4)
        ) / 3
        
        return 0.7 * layer_sim + 0.3 * param_sim
        
    def _compare_layers(self, layers1: List[Dict], layers2: List[Dict]) -> float:
        """Compare layer structures for similarity"""
        if not layers1 or not layers2:
            return 0.0
            
        similarity = 0
        max_layers = max(len(layers1), len(layers2))
        
        for i in range(min(len(layers1), len(layers2))):
            if layers1[i]['type'] == layers2[i]['type']:
                similarity += 1
                if abs(layers1[i]['units'] - layers2[i]['units']) / max(layers1[i]['units'], layers2[i]['units']) < 0.2:
                    similarity += 0.5
                    
        return similarity / (2 * max_layers)

    def get_best_architecture(self) -> Optional[Dict]:
        """Get the best architecture found so far"""
        if not self.architecture_queue.empty():
            return self.architecture_queue.get()[1]
        return None 