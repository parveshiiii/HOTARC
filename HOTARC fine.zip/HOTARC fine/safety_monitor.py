import psutil
import threading
import time
import json
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass
from datetime import datetime
import torch
from collections import deque
import logging
from scipy import stats
import os

@dataclass
class SafetyMetrics:
    cpu_usage: float
    memory_usage: float
    gpu_usage: Optional[float]
    model_complexity: float
    decision_confidence: float
    ethical_alignment: float
    resource_efficiency: float
    response_coherence: float
    output_stability: float
    behavioral_consistency: float
    learning_rate: float
    error_rate: float
    recovery_rate: float
    model_stability: float
    ethical_compliance: float
    system_integrity: float
    last_update: float

@dataclass
class SafetyThresholds:
    max_cpu_usage: float = 90.0
    max_memory_usage: float = 85.0
    min_model_stability: float = 0.8
    min_ethical_compliance: float = 0.95
    min_system_integrity: float = 0.9

class SafetyMonitor:
    def __init__(self, hotarc):
        self.hotarc = hotarc
        self.setup_logging()
        self.initialize_safety_system()
        
    def setup_logging(self):
        """Setup logging configuration"""
        self.logger = logging.getLogger('SafetyMonitor')
        
    def initialize_safety_system(self):
        """Initialize the safety monitoring system"""
        self.metrics = SafetyMetrics(0.0, 0.0, None, 0.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, time.time())
        self.thresholds = SafetyThresholds()
        self.alert_callbacks: List[Callable] = []
        self.violation_counts: Dict[str, int] = {}
        self.safety_lock = threading.Lock()
        self._shutdown_flag = False
        
        # Create safety state directory
        self.safety_dir = Path("safety_states")
        self.safety_dir.mkdir(exist_ok=True)
        
    def start(self):
        """Start safety monitoring"""
        self.logger.info("Starting safety monitoring system...")
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(target=self._monitoring_loop)
        self.monitor_thread.start()
        
        # Start periodic safety checks
        self.check_thread = threading.Thread(target=self._safety_check_loop)
        self.check_thread.start()
        
    def stop(self):
        """Stop safety monitoring"""
        self.logger.info("Stopping safety monitoring system...")
        self._shutdown_flag = True
        
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join()
        if hasattr(self, 'check_thread'):
            self.check_thread.join()
            
    def register_alert_callback(self, callback: Callable):
        """Register a callback for safety alerts"""
        self.alert_callbacks.append(callback)
        
    def _monitoring_loop(self):
        """Main monitoring loop"""
        while not self._shutdown_flag:
            try:
                self._update_safety_metrics()
                self._check_thresholds()
                time.sleep(1)  # Check every second
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                
    def _safety_check_loop(self):
        """Periodic comprehensive safety checks"""
        while not self._shutdown_flag:
            try:
                self._perform_safety_audit()
                self._verify_system_integrity()
                self._check_component_health()
                time.sleep(60)  # Comprehensive check every minute
            except Exception as e:
                self.logger.error(f"Error in safety check loop: {e}")
                
    def _update_safety_metrics(self):
        """Update safety metrics"""
        try:
            with self.safety_lock:
                # Update system metrics
                self.metrics.cpu_usage = psutil.cpu_percent() / 100.0
                self.metrics.memory_usage = psutil.virtual_memory().percent / 100.0
                
                # Update model stability
                self.metrics.model_stability = self._calculate_model_stability()
                
                # Update ethical compliance
                self.metrics.ethical_compliance = self._check_ethical_compliance()
                
                # Update system integrity
                self.metrics.system_integrity = self._check_system_integrity()
                
                self.metrics.last_update = time.time()
                
        except Exception as e:
            self.logger.error(f"Error updating safety metrics: {e}")
            
    def _check_thresholds(self):
        """Check if any safety thresholds are violated"""
        with self.safety_lock:
            violations = []
            
            # Check CPU usage
            if self.metrics.cpu_usage > self.thresholds.max_cpu_usage:
                violations.append(("CPU_USAGE", f"CPU usage too high: {self.metrics.cpu_usage}%"))
                
            # Check memory usage
            if self.metrics.memory_usage > self.thresholds.max_memory_usage:
                violations.append(("MEMORY_USAGE", f"Memory usage too high: {self.metrics.memory_usage}%"))
                
            # Check model stability
            if self.metrics.model_stability < self.thresholds.min_model_stability:
                violations.append(("MODEL_STABILITY", f"Model stability too low: {self.metrics.model_stability}"))
                
            # Check ethical compliance
            if self.metrics.ethical_compliance < self.thresholds.min_ethical_compliance:
                violations.append(("ETHICAL_COMPLIANCE", f"Ethical compliance below threshold: {self.metrics.ethical_compliance}"))
                
            # Check system integrity
            if self.metrics.system_integrity < self.thresholds.min_system_integrity:
                violations.append(("SYSTEM_INTEGRITY", f"System integrity compromised: {self.metrics.system_integrity}"))
                
            # Handle violations
            for violation_type, message in violations:
                self._handle_violation(violation_type, message)
                
    def _handle_violation(self, violation_type: str, message: str):
        """Handle safety violations"""
        # Update violation count
        self.violation_counts[violation_type] = self.violation_counts.get(violation_type, 0) + 1
        
        # Determine severity
        count = self.violation_counts[violation_type]
        if count >= 10:
            severity = "CRITICAL"
        elif count >= 5:
            severity = "HIGH"
        else:
            severity = "WARNING"
            
        # Create alert
        alert = {
            'type': violation_type,
            'message': message,
            'severity': severity,
            'timestamp': datetime.now().isoformat(),
            'metrics': self._get_current_metrics()
        }
        
        # Log alert
        self.logger.warning(f"Safety violation: {alert}")
        
        # Notify callbacks
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Error in alert callback: {e}")
                
        # Take action based on severity
        if severity == "CRITICAL":
            self._handle_critical_violation(alert)
            
    def _handle_critical_violation(self, alert: Dict):
        """Handle critical safety violations"""
        try:
            # Save current state
            self._save_safety_state()
            
            # Stop hot-swapping
            if hasattr(self.hotarc, 'hot_swap'):
                self.hotarc.hot_swap.stop_watching()
                
            # Initiate emergency shutdown if necessary
            if alert['type'] in ['SYSTEM_INTEGRITY', 'ETHICAL_COMPLIANCE']:
                self.logger.critical("Initiating emergency shutdown due to critical violation")
                self.hotarc.shutdown()
                
        except Exception as e:
            self.logger.error(f"Error handling critical violation: {e}")
            
    def _calculate_model_stability(self) -> float:
        """Calculate model stability score"""
        try:
            if not hasattr(self.hotarc, 'hot_swap'):
                return 1.0
                
            # Get active modules
            active_modules = self.hotarc.hot_swap.active_modules
            if not active_modules:
                return 1.0
                
            # Calculate stability based on performance metrics
            stability_scores = []
            for name, module in active_modules.items():
                if hasattr(module, 'get_performance_metrics'):
                    metrics = module.get_performance_metrics()
                    if metrics.get('stability'):
                        stability_scores.append(metrics['stability'])
                        
            return np.mean(stability_scores) if stability_scores else 1.0
            
        except Exception as e:
            self.logger.error(f"Error calculating model stability: {e}")
            return 1.0
            
    def _check_ethical_compliance(self) -> float:
        """Check ethical compliance of the system"""
        try:
            if hasattr(self.hotarc, 'ethics'):
                return self.hotarc.ethics.get_compliance_score()
            return 1.0
        except Exception as e:
            self.logger.error(f"Error checking ethical compliance: {e}")
            return 1.0
            
    def _check_system_integrity(self) -> float:
        """Check system integrity"""
        try:
            # Verify component health
            components_ok = self._verify_component_health()
            
            # Check file system integrity
            files_ok = self._verify_file_integrity()
            
            # Check memory integrity
            memory_ok = self._verify_memory_integrity()
            
            return min(components_ok, files_ok, memory_ok)
            
        except Exception as e:
            self.logger.error(f"Error checking system integrity: {e}")
            return 1.0
            
    def _verify_component_health(self) -> float:
        """Verify health of all system components"""
        try:
            if not hasattr(self.hotarc, 'hot_swap'):
                return 1.0
                
            healthy_count = 0
            total_count = 0
            
            for name, state in self.hotarc.hot_swap.module_states.items():
                if state.is_active:
                    total_count += 1
                    if self._check_component_integrity(name):
                        healthy_count += 1
                        
            return healthy_count / total_count if total_count > 0 else 1.0
            
        except Exception as e:
            self.logger.error(f"Error verifying component health: {e}")
            return 1.0
            
    def _check_component_integrity(self, component_name: str) -> bool:
        """Check integrity of a specific component"""
        try:
            component = self.hotarc.hot_swap.active_modules.get(component_name)
            if not component:
                return False
                
            # Check if component has required attributes
            required_attrs = ['execute', 'get_state']
            if not all(hasattr(component, attr) for attr in required_attrs):
                return False
                
            # Check if component can execute
            if hasattr(component, 'is_healthy'):
                return component.is_healthy()
                
            return True
            
        except Exception:
            return False
            
    def _verify_file_integrity(self) -> float:
        """Verify integrity of critical system files"""
        try:
            critical_files = [
                'M1.py',
                'hot_swap_manager.py',
                'safety_monitor.py',
                'config.py'
            ]
            
            existing_count = 0
            for file in critical_files:
                if os.path.exists(file):
                    existing_count += 1
                    
            return existing_count / len(critical_files)
            
        except Exception as e:
            self.logger.error(f"Error verifying file integrity: {e}")
            return 1.0
            
    def _verify_memory_integrity(self) -> float:
        """Verify system memory integrity"""
        try:
            # Check virtual memory
            vm = psutil.virtual_memory()
            if vm.available < 1024 * 1024 * 100:  # Less than 100MB available
                return 0.5
                
            # Check swap usage
            swap = psutil.swap_memory()
            if swap.percent > 80:
                return 0.7
                
            return 1.0
            
        except Exception as e:
            self.logger.error(f"Error verifying memory integrity: {e}")
            return 1.0
            
    def _perform_safety_audit(self):
        """Perform comprehensive safety audit"""
        try:
            audit_results = {
                'timestamp': datetime.now().isoformat(),
                'metrics': self._get_current_metrics(),
                'violations': self.violation_counts.copy(),
                'components': self._get_component_status(),
                'system_health': {
                    'cpu_ok': self.metrics.cpu_usage < self.thresholds.max_cpu_usage,
                    'memory_ok': self.metrics.memory_usage < self.thresholds.max_memory_usage,
                    'model_stability_ok': self.metrics.model_stability >= self.thresholds.min_model_stability,
                    'ethical_compliance_ok': self.metrics.ethical_compliance >= self.thresholds.min_ethical_compliance,
                    'system_integrity_ok': self.metrics.system_integrity >= self.thresholds.min_system_integrity
                }
            }
            
            # Save audit results
            audit_file = self.safety_dir / f"safety_audit_{int(time.time())}.json"
            with open(audit_file, 'w') as f:
                json.dump(audit_results, f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Error performing safety audit: {e}")
            
    def _get_current_metrics(self) -> Dict:
        """Get current safety metrics"""
        return {
            'cpu_usage': self.metrics.cpu_usage,
            'memory_usage': self.metrics.memory_usage,
            'model_stability': self.metrics.model_stability,
            'ethical_compliance': self.metrics.ethical_compliance,
            'system_integrity': self.metrics.system_integrity,
            'last_update': datetime.fromtimestamp(self.metrics.last_update).isoformat()
        }
        
    def _get_component_status(self) -> Dict:
        """Get status of all system components"""
        status = {}
        if hasattr(self.hotarc, 'hot_swap'):
            for name, state in self.hotarc.hot_swap.module_states.items():
                status[name] = {
                    'active': state.is_active,
                    'version': state.version,
                    'last_update': datetime.fromtimestamp(state.last_update).isoformat(),
                    'healthy': self._check_component_integrity(name)
                }
        return status
        
    def _save_safety_state(self):
        """Save current safety state"""
        try:
            state = {
                'timestamp': datetime.now().isoformat(),
                'metrics': self._get_current_metrics(),
                'thresholds': {
                    'max_cpu_usage': self.thresholds.max_cpu_usage,
                    'max_memory_usage': self.thresholds.max_memory_usage,
                    'min_model_stability': self.thresholds.min_model_stability,
                    'min_ethical_compliance': self.thresholds.min_ethical_compliance,
                    'min_system_integrity': self.thresholds.min_system_integrity
                },
                'violations': self.violation_counts.copy(),
                'components': self._get_component_status()
            }
            
            state_file = self.safety_dir / f"safety_state_{int(time.time())}.json"
            with open(state_file, 'w') as f:
                json.dump(state, f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Error saving safety state: {e}")
            
    def is_critical_error(self, error: Exception) -> bool:
        """Determine if an error is critical"""
        try:
            # Check error type
            if isinstance(error, (MemoryError, SystemError)):
                return True
                
            # Check system state
            if (self.metrics.system_integrity < 0.5 or
                self.metrics.ethical_compliance < 0.5):
                return True
                
            # Check violation counts
            critical_violations = sum(1 for count in self.violation_counts.values() if count >= 10)
            if critical_violations >= 3:
                return True
                
            return False
            
        except Exception:
            return True  # Assume critical if we can't determine 