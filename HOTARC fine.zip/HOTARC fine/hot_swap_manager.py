import os
import time
import torch
import shutil
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from transformers import AutoModel, AutoTokenizer
import threading
from typing import Dict, Optional, List, Any
import json
from dataclasses import dataclass
from datetime import datetime
import logging
import numpy as np

@dataclass
class ModuleState:
    """State information for a module"""
    name: str
    version: int
    last_update: float
    performance_metrics: Dict
    dependencies: List[str]
    is_active: bool

class ModelWatcher(FileSystemEventHandler):
    def __init__(self, manager):
        self.manager = manager
        
    def on_modified(self, event):
        if event.src_path.endswith('.pth'):
            self.manager.logger.info(f"Detected model update: {event.src_path}")
            # Handle model update logic here

class ModuleWatcher(FileSystemEventHandler):
    def __init__(self, manager):
        self.manager = manager
        
    def on_modified(self, event):
        if event.src_path.endswith('.py'):
            module_name = Path(event.src_path).stem
            if module_name in self.manager.module_states:
                self.manager.logger.info(f"Detected module update: {module_name}")
                # Handle module update logic here

class HotSwapManager:
    def __init__(self, config):
        self.config = config
        self.module_states = {}
        self.active_modules = {}
        self.swap_lock = threading.Lock()
        self.state_file = Path("module_states.json")
        self.backup_dir = Path("module_backups")
        self.backup_dir.mkdir(exist_ok=True)
        self.template_dir = Path("module_templates")
        self.template_dir.mkdir(exist_ok=True)
        
        # Setup logging
        self._setup_logging()
        
        # Initialize observers
        self.observers = []
        self.event_handlers = {}
        
        # Load existing state
        self._load_state()
        
        # Initialize module templates
        self._initialize_templates()
        
    def _setup_logging(self):
        """Setup logging configuration"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('hot_swap.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger('HotSwapManager')
        
    def start_watching(self):
        """Start watching for module changes"""
        # Watch model directory
        model_observer = Observer()
        model_handler = ModelWatcher(self)
        model_observer.schedule(model_handler, str(self.config.model_dir), recursive=False)
        model_observer.start()
        self.observers.append(model_observer)
        
        # Watch module directory
        module_observer = Observer()
        module_handler = ModuleWatcher(self)
        module_observer.schedule(module_handler, ".", recursive=True)
        module_observer.start()
        self.observers.append(module_observer)
        
        self.logger.info("Hot-swapping enabled - watching for updates...")
        
    def stop_watching(self):
        """Stop all file watchers"""
        for observer in self.observers:
            if observer.is_alive():
                observer.stop()
                observer.join()
                
    def register_module(self, module_name: str, module, dependencies: List[str] = None):
        """Register a module for hot-swapping"""
        with self.swap_lock:
            self.module_states[module_name] = ModuleState(
                name=module_name,
                version=1,
                last_update=time.time(),
                performance_metrics={},
                dependencies=dependencies or [],
                is_active=True
            )
            self.active_modules[module_name] = module
            self._save_state()
            
    def hot_swap_module(self, module_name: str, new_module) -> bool:
        """Perform hot-swap of a module"""
        with self.swap_lock:
            try:
                if module_name not in self.module_states:
                    self.logger.error(f"Module {module_name} not registered")
                    return False
                    
                # Verify dependencies
                if not self._verify_dependencies(module_name):
                    return False
                    
                # Create backup
                self._backup_module(module_name)
                
                # Update module
                old_module = self.active_modules[module_name]
                self._transfer_state(old_module, new_module)
                self.active_modules[module_name] = new_module
                
                # Update state
                state = self.module_states[module_name]
                state.version += 1
                state.last_update = time.time()
                
                self._save_state()
                self.logger.info(f"Successfully hot-swapped module: {module_name}")
                return True
                
            except Exception as e:
                self.logger.error(f"Error during hot-swap of {module_name}: {e}")
                self._attempt_rollback(module_name)
                return False
                
    def _verify_dependencies(self, module_name: str) -> bool:
        """Verify module dependencies before swap"""
        state = self.module_states[module_name]
        for dep in state.dependencies:
            if dep not in self.active_modules or not self.module_states[dep].is_active:
                self.logger.error(f"Dependency {dep} not available for {module_name}")
                return False
        return True
        
    def _backup_module(self, module_name: str):
        """Create backup of module before swap"""
        state = self.module_states[module_name]
        backup_path = self.backup_dir / f"{module_name}_v{state.version}_{int(time.time())}.bak"
        
        try:
            with open(backup_path, 'wb') as f:
                torch.save({
                    'module': self.active_modules[module_name],
                    'state': state
                }, f)
        except Exception as e:
            self.logger.error(f"Error creating backup for {module_name}: {e}")
            raise
            
    def _transfer_state(self, old_module, new_module):
        """Transfer necessary state from old module to new module"""
        try:
            # Transfer basic attributes
            for attr in dir(old_module):
                if not attr.startswith('_') and hasattr(new_module, attr):
                    setattr(new_module, attr, getattr(old_module, attr))
                    
            # Transfer model weights if applicable
            if hasattr(old_module, 'state_dict') and hasattr(new_module, 'load_state_dict'):
                new_module.load_state_dict(old_module.state_dict())
                
        except Exception as e:
            self.logger.error(f"Error transferring state: {e}")
            raise
            
    def _attempt_rollback(self, module_name: str):
        """Attempt to rollback to last working version"""
        try:
            # Find latest backup
            backups = list(self.backup_dir.glob(f"{module_name}_v*"))
            if not backups:
                return
                
            latest_backup = max(backups, key=lambda p: int(p.stem.split('_')[-1]))
            
            # Load backup
            with open(latest_backup, 'rb') as f:
                backup = torch.load(f)
                
            # Restore module
            self.active_modules[module_name] = backup['module']
            self.module_states[module_name] = backup['state']
            
            self.logger.info(f"Successfully rolled back {module_name}")
            
        except Exception as e:
            self.logger.error(f"Error during rollback of {module_name}: {e}")
            
    def _save_state(self):
        """Save current state to file"""
        try:
            state = {
                name: {
                    'version': state.version,
                    'last_update': state.last_update,
                    'performance_metrics': state.performance_metrics,
                    'dependencies': state.dependencies,
                    'is_active': state.is_active
                }
                for name, state in self.module_states.items()
            }
            
            with open(self.state_file, 'w') as f:
                json.dump(state, f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Error saving state: {e}")
            
    def _load_state(self):
        """Load state from file"""
        try:
            if self.state_file.exists():
                with open(self.state_file, 'r') as f:
                    state = json.load(f)
                    
                for name, data in state.items():
                    self.module_states[name] = ModuleState(
                        name=name,
                        version=data['version'],
                        last_update=data['last_update'],
                        performance_metrics=data['performance_metrics'],
                        dependencies=data['dependencies'],
                        is_active=data['is_active']
                    )
                    
        except Exception as e:
            self.logger.error(f"Error loading state: {e}")
            
    def get_module_info(self, module_name: str) -> Optional[Dict]:
        """Get information about a module"""
        if module_name not in self.module_states:
            return None
            
        state = self.module_states[module_name]
        return {
            'name': state.name,
            'version': state.version,
            'last_update': datetime.fromtimestamp(state.last_update).isoformat(),
            'is_active': state.is_active,
            'dependencies': state.dependencies,
            'performance_metrics': state.performance_metrics
        }
        
    def update_performance_metrics(self, module_name: str, metrics: Dict):
        """Update performance metrics for a module"""
        if module_name in self.module_states:
            self.module_states[module_name].performance_metrics.update(metrics)
            self._save_state()
            
    def _initialize_templates(self):
        """Initialize module templates for dynamic creation"""
        self.templates = {
            'processor': '''
                class {name}(BaseProcessor):
                    def __init__(self):
                        super().__init__()
                        {init_code}
                    
                    def process(self, data):
                        {process_code}
            ''',
            'analyzer': '''
                class {name}(BaseAnalyzer):
                    def __init__(self):
                        super().__init__()
                        {init_code}
                    
                    def analyze(self, data):
                        {analyze_code}
            ''',
            'optimizer': '''
                class {name}(BaseOptimizer):
                    def __init__(self):
                        super().__init__()
                        {init_code}
                    
                    def optimize(self, data):
                        {optimize_code}
            '''
        }
        
    def create_new_module(self, module_spec: Dict) -> bool:
        """Create a new module dynamically"""
        try:
            # Generate module code
            module_code = self._generate_module_code(module_spec)
            
            # Validate code
            if not self._validate_generated_code(module_code):
                return False
                
            # Create module
            module = self._create_module_from_code(module_code)
            
            # Register module
            self.register_module(
                module_spec['name'],
                module,
                module_spec.get('dependencies', [])
            )
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create new module: {e}")
            return False
            
    def _generate_module_code(self, spec: Dict) -> str:
        """Generate module code from specification"""
        try:
            template = self.templates.get(spec['type'])
            if not template:
                raise ValueError(f"Unknown module type: {spec['type']}")
                
            return template.format(
                name=spec['name'],
                init_code=spec.get('init_code', 'pass'),
                process_code=spec.get('process_code', 'pass'),
                analyze_code=spec.get('analyze_code', 'pass'),
                optimize_code=spec.get('optimize_code', 'pass')
            )
            
        except Exception as e:
            self.logger.error(f"Code generation failed: {e}")
            return None
            
    def _validate_generated_code(self, code: str) -> bool:
        """Validate generated code"""
        try:
            # Syntax check
            compile(code, '<string>', 'exec')
            
            # Security check
            if self._contains_unsafe_code(code):
                return False
                
            return True
            
        except Exception as e:
            self.logger.error(f"Code validation failed: {e}")
            return False
            
    def _contains_unsafe_code(self, code: str) -> bool:
        """Check for unsafe code patterns"""
        unsafe_patterns = [
            'eval(',
            'exec(',
            '__import__',
            'subprocess',
            'os.system'
        ]
        return any(pattern in code for pattern in unsafe_patterns)
        
    def _create_module_from_code(self, code: str) -> Any:
        """Create module object from code"""
        try:
            # Create module namespace
            namespace = {}
            
            # Execute code in namespace
            exec(code, namespace)
            
            # Find and return main class
            for item in namespace.values():
                if isinstance(item, type):
                    return item()
                    
            return None
            
        except Exception as e:
            self.logger.error(f"Module creation failed: {e}")
            return None 