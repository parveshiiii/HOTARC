import os
from pathlib import Path
from typing import Dict, Any
import json

class Config:
    def __init__(self, config_path: str = "config.json"):
        self.config_path = config_path
        self.load_config()
        
    def load_config(self):
        """Load configuration from file"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    config = json.load(f)
            else:
                config = self._get_default_config()
                self.save_config(config)
                
            self._initialize_config(config)
            
        except Exception as e:
            print(f"Error loading config: {e}")
            config = self._get_default_config()
            self._initialize_config(config)
            
    def _initialize_config(self, config: Dict[str, Any]):
        """Initialize configuration attributes"""
        # System paths
        self.model_dir = Path(config.get('model_dir', 'models'))
        self.backup_dir = Path(config.get('backup_dir', 'backups'))
        self.log_dir = Path(config.get('log_dir', 'logs'))
        
        # Create necessary directories
        for directory in [self.model_dir, self.backup_dir, self.log_dir]:
            directory.mkdir(exist_ok=True)
            
        # Hot-swapping configuration
        self.hot_swap_config = {
            'enabled': config.get('hot_swap', {}).get('enabled', True),
            'backup_modules': config.get('hot_swap', {}).get('backup_modules', True),
            'max_backups': config.get('hot_swap', {}).get('max_backups', 5),
            'auto_recovery': config.get('hot_swap', {}).get('auto_recovery', True),
            'state_transfer': config.get('hot_swap', {}).get('state_transfer', True),
            'monitoring_interval': config.get('hot_swap', {}).get('monitoring_interval', 60)
        }
        
        # Safety monitoring configuration
        self.safety_config = {
            'enabled': config.get('safety', {}).get('enabled', True),
            'max_cpu_usage': config.get('safety', {}).get('max_cpu_usage', 90.0),
            'max_memory_usage': config.get('safety', {}).get('max_memory_usage', 85.0),
            'min_model_stability': config.get('safety', {}).get('min_model_stability', 0.8),
            'min_ethical_compliance': config.get('safety', {}).get('min_ethical_compliance', 0.95),
            'min_system_integrity': config.get('safety', {}).get('min_system_integrity', 0.9),
            'check_interval': config.get('safety', {}).get('check_interval', 1),
            'audit_interval': config.get('safety', {}).get('audit_interval', 3600)
        }
        
        # Model configuration
        self.model_config = {
            'use_local_models': config.get('model', {}).get('use_local_models', True),
            'download_models': config.get('model', {}).get('download_models', False),
            'model_format': config.get('model', {}).get('model_format', 'pth'),
            'default_device': config.get('model', {}).get('default_device', 'cuda' if self._has_cuda() else 'cpu')
        }
        
        # System configuration
        self.system_config = {
            'debug_mode': config.get('system', {}).get('debug_mode', False),
            'log_level': config.get('system', {}).get('log_level', 'INFO'),
            'max_threads': config.get('system', {}).get('max_threads', os.cpu_count()),
            'memory_limit': config.get('system', {}).get('memory_limit', '80%')
        }
        
        # Component configuration
        self.component_config = {
            'reasoning_core': {
                'enabled': config.get('components', {}).get('reasoning_core', {}).get('enabled', True),
                'model_type': config.get('components', {}).get('reasoning_core', {}).get('model_type', 'transformer'),
                'batch_size': config.get('components', {}).get('reasoning_core', {}).get('batch_size', 32)
            },
            'ethical_intelligence': {
                'enabled': config.get('components', {}).get('ethical_intelligence', {}).get('enabled', True),
                'strict_mode': config.get('components', {}).get('ethical_intelligence', {}).get('strict_mode', True)
            },
            'memory_management': {
                'enabled': config.get('components', {}).get('memory_management', {}).get('enabled', True),
                'cache_size': config.get('components', {}).get('memory_management', {}).get('cache_size', '1GB')
            },
            'neural_search': {
                'enabled': config.get('components', {}).get('neural_search', {}).get('enabled', True),
                'search_algorithm': config.get('components', {}).get('neural_search', {}).get('search_algorithm', 'evolutionary')
            }
        }
        
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            'model_dir': 'models',
            'backup_dir': 'backups',
            'log_dir': 'logs',
            'hot_swap': {
                'enabled': True,
                'backup_modules': True,
                'max_backups': 5,
                'auto_recovery': True,
                'state_transfer': True,
                'monitoring_interval': 60
            },
            'safety': {
                'enabled': True,
                'max_cpu_usage': 90.0,
                'max_memory_usage': 85.0,
                'min_model_stability': 0.8,
                'min_ethical_compliance': 0.95,
                'min_system_integrity': 0.9,
                'check_interval': 1,
                'audit_interval': 3600
            },
            'model': {
                'use_local_models': True,
                'download_models': False,
                'model_format': 'pth',
                'default_device': 'cuda' if self._has_cuda() else 'cpu'
            },
            'system': {
                'debug_mode': False,
                'log_level': 'INFO',
                'max_threads': os.cpu_count(),
                'memory_limit': '80%'
            },
            'components': {
                'reasoning_core': {
                    'enabled': True,
                    'model_type': 'transformer',
                    'batch_size': 32
                },
                'ethical_intelligence': {
                    'enabled': True,
                    'strict_mode': True
                },
                'memory_management': {
                    'enabled': True,
                    'cache_size': '1GB'
                },
                'neural_search': {
                    'enabled': True,
                    'search_algorithm': 'evolutionary'
                }
            }
        }
        
    def save_config(self, config: Dict[str, Any] = None):
        """Save configuration to file"""
        if config is None:
            config = {
                'model_dir': str(self.model_dir),
                'backup_dir': str(self.backup_dir),
                'log_dir': str(self.log_dir),
                'hot_swap': self.hot_swap_config,
                'safety': self.safety_config,
                'model': self.model_config,
                'system': self.system_config,
                'components': self.component_config
            }
            
        try:
            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            print(f"Error saving config: {e}")
            
    def get_model_path(self, model_name: str) -> Path:
        """Get path for a model file"""
        return self.model_dir / f"{model_name}.{self.model_config['model_format']}"
        
    def _has_cuda(self) -> bool:
        """Check if CUDA is available"""
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            return False
            
    def update_config(self, updates: Dict[str, Any]):
        """Update configuration with new values"""
        try:
            # Load current config
            with open(self.config_path, 'r') as f:
                config = json.load(f)
                
            # Update recursively
            self._update_dict_recursive(config, updates)
            
            # Save updated config
            self.save_config(config)
            
            # Reinitialize with new config
            self._initialize_config(config)
            
        except Exception as e:
            print(f"Error updating config: {e}")
            
    def _update_dict_recursive(self, d: Dict, u: Dict):
        """Recursively update dictionary"""
        for k, v in u.items():
            if isinstance(v, dict):
                d[k] = self._update_dict_recursive(d.get(k, {}), v)
            else:
                d[k] = v
        return d 