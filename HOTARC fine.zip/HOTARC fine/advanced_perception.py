from transformers import pipeline, AutoModelForSequenceClassification, AutoTokenizer
import whisper
import cv2
import numpy as np
import logging
from scipy.stats import norm
import torch
import torch.nn as nn
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
import threading
from queue import PriorityQueue
import time
from pathlib import Path
import json
from PIL import Image
import librosa
import soundfile as sf
from concurrent.futures import ThreadPoolExecutor

@dataclass
class PerceptionInput:
    """Input for perception processing"""
    input_id: str
    input_type: str  # 'text', 'image', 'audio', 'video', 'code'
    data: Any
    metadata: Dict[str, Any]
    priority: float
    timestamp: float

@dataclass
class PerceptionResult:
    """Result of perception processing"""
    input_id: str
    perceptions: Dict[str, Any]
    confidence_scores: Dict[str, float]
    processing_time: float
    modality: str
    context: Dict[str, Any]

class AdvancedPerception:
    def __init__(self, hotarc):
        self.hotarc = hotarc
        self.setup_logging()
        self.setup_models()
        self.perception_queue = PriorityQueue()
        self.perception_results: Dict[str, PerceptionResult] = {}
        self.context_history: List[Dict[str, Any]] = []
        self.lock = threading.Lock()
        self._shutdown = False
        
        # Initialize perception thread
        self.perception_thread = threading.Thread(target=self._continuous_perception)
        self.perception_thread.daemon = True
        self.perception_thread.start()
        
    def setup_logging(self):
        """Setup logging configuration"""
        logging.basicConfig(
            filename='advanced_perception.log',
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('AdvancedPerception')
        
    def setup_models(self):
        """Initialize perception models"""
        try:
            # Text analysis models
            self.text_analyzer = pipeline(
                "sentiment-analysis",
                model="nlptown/bert-base-multilingual-uncased-sentiment"
            )
            self.code_analyzer = pipeline(
                "code-to-text",
                model="Salesforce/codet5-base"
            )
            
            # Speech recognition
            self.speech_recognizer = whisper.load_model("base")
            
            # Image analysis
            self.face_cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            )
            self.image_classifier = pipeline(
                "image-classification",
                model="microsoft/resnet-50"
            )
            
            self.logger.info("Successfully initialized all perception models")
            
        except Exception as e:
            self.logger.error(f"Error setting up models: {e}")
            
    def execute(self):
        """Main execution cycle"""
        try:
            # Process multi-modal inputs
            self.multi_modal_perception()
            
            # Optimize neural networks
            self.neural_network_optimization()
            
            # Update emotion-aware reasoning
            self.emotion_aware_reasoning()
            
        except Exception as e:
            self.logger.error(f"Error in execute cycle: {e}")
            
    def process_input(self, input_data: Any, input_type: str, metadata: Dict[str, Any] = None):
        """Process new perception input"""
        try:
            # Create perception input
            perception_input = PerceptionInput(
                input_id=f"input_{time.time()}",
                input_type=input_type,
                data=input_data,
                metadata=metadata or {},
                priority=self._calculate_priority(input_type, metadata),
                timestamp=time.time()
            )
            
            # Queue input for processing
            self.perception_queue.put((-perception_input.priority, perception_input))
            
            self.logger.info(f"Queued {input_type} input {perception_input.input_id}")
            
        except Exception as e:
            self.logger.error(f"Error processing input: {e}")
            
    def _calculate_priority(self, input_type: str, metadata: Dict[str, Any]) -> float:
        """Calculate processing priority"""
        try:
            priority = 1.0
            
            # Type-based priority
            type_priorities = {
                'video': 2.0,
                'audio': 1.5,
                'image': 1.2,
                'text': 1.0,
                'code': 1.0
            }
            priority *= type_priorities.get(input_type, 1.0)
            
            # Metadata-based priority
            if metadata:
                if metadata.get('urgent', False):
                    priority *= 2.0
                if metadata.get('importance', 0) > 0:
                    priority *= (1.0 + metadata['importance'])
                    
            return priority
            
        except Exception as e:
            self.logger.error(f"Error calculating priority: {e}")
            return 1.0
            
    def _continuous_perception(self):
        """Continuous perception processing"""
        while not self._shutdown:
            try:
                if not self.perception_queue.empty():
                    # Get highest priority input
                    _, perception_input = self.perception_queue.get()
                    
                    # Process input
                    result = self._process_perception(perception_input)
                    
                    # Store result
                    if result:
                        with self.lock:
                            self.perception_results[perception_input.input_id] = result
                            self._update_context(result)
                            
                time.sleep(0.1)  # Small delay between inputs
                
            except Exception as e:
                self.logger.error(f"Error in continuous perception: {e}")
                
    def _process_perception(self, perception_input: PerceptionInput) -> Optional[PerceptionResult]:
        """Process a single perception input"""
        try:
            start_time = time.time()
            
            # Process based on input type
            if perception_input.input_type == 'text':
                perceptions = self._process_text(perception_input.data)
            elif perception_input.input_type == 'image':
                perceptions = self._process_image(perception_input.data)
            elif perception_input.input_type == 'audio':
                perceptions = self._process_audio(perception_input.data)
            elif perception_input.input_type == 'video':
                perceptions = self._process_video(perception_input.data)
            elif perception_input.input_type == 'code':
                perceptions = self._process_code(perception_input.data)
            else:
                self.logger.warning(f"Unsupported input type: {perception_input.input_type}")
                return None
                
            # Calculate confidence scores
            confidence_scores = self._calculate_confidence(perceptions)
            
            # Get relevant context
            context = self._get_relevant_context(perception_input.input_type)
            
            processing_time = time.time() - start_time
            
            return PerceptionResult(
                input_id=perception_input.input_id,
                perceptions=perceptions,
                confidence_scores=confidence_scores,
                processing_time=processing_time,
                modality=perception_input.input_type,
                context=context
            )
            
        except Exception as e:
            self.logger.error(f"Error processing perception: {e}")
            return None
            
    def _process_text(self, text: str) -> Dict[str, Any]:
        """Process text input"""
        try:
            return {
                'sentiment': self.text_analyzer(text),
                'entities': self._extract_entities(text),
                'topics': self._extract_topics(text),
                'summary': self._generate_summary(text)
            }
        except Exception as e:
            self.logger.error(f"Error processing text: {e}")
            return {}
            
    def _process_image(self, image: np.ndarray) -> Dict[str, Any]:
        """Process image input"""
        try:
            # Convert to PIL Image if needed
            if isinstance(image, np.ndarray):
                image = Image.fromarray(image)
                
            return {
                'classification': self.image_classifier(image),
                'objects': self._detect_objects(image),
                'faces': self._detect_faces(image),
                'scene_analysis': self._analyze_scene(image)
            }
        except Exception as e:
            self.logger.error(f"Error processing image: {e}")
            return {}
            
    def _process_audio(self, audio: np.ndarray) -> Dict[str, Any]:
        """Process audio input"""
        try:
            return {
                'transcription': self.speech_recognizer.transcribe(audio),
                'speaker_analysis': self._analyze_speaker(audio),
                'emotion': self._detect_audio_emotion(audio),
                'noise_profile': self._analyze_noise(audio)
            }
        except Exception as e:
            self.logger.error(f"Error processing audio: {e}")
            return {}
            
    def _process_video(self, video: np.ndarray) -> Dict[str, Any]:
        """Process video input"""
        try:
            return {
                'frames_analysis': self._analyze_frames(video),
                'motion_tracking': self._track_motion(video),
                'scene_changes': self._detect_scene_changes(video),
                'activity_recognition': self._recognize_activity(video)
            }
        except Exception as e:
            self.logger.error(f"Error processing video: {e}")
            return {}
            
    def _process_code(self, code: str) -> Dict[str, Any]:
        """Process code input"""
        try:
            return {
                'summary': self.code_analyzer(code),
                'complexity': self._analyze_code_complexity(code),
                'patterns': self._detect_code_patterns(code),
                'quality': self._assess_code_quality(code)
            }
        except Exception as e:
            self.logger.error(f"Error processing code: {e}")
            return {}
            
    def _calculate_confidence(self, perceptions: Dict[str, Any]) -> Dict[str, float]:
        """Calculate confidence scores for perceptions"""
        try:
            confidence_scores = {}
            for key, value in perceptions.items():
                if isinstance(value, list):
                    confidence_scores[key] = np.mean([item.get('score', 0.0) for item in value])
                elif isinstance(value, dict):
                    confidence_scores[key] = value.get('score', 0.0)
                else:
                    confidence_scores[key] = 1.0
            return confidence_scores
            
        except Exception as e:
            self.logger.error(f"Error calculating confidence: {e}")
            return {}
            
    def _get_relevant_context(self, modality: str) -> Dict[str, Any]:
        """Get relevant context for current perception"""
        try:
            relevant_context = {}
            
            # Get recent context history
            recent_context = self.context_history[-5:] if self.context_history else []
            
            # Filter by modality
            modality_context = [
                ctx for ctx in recent_context
                if ctx.get('modality') == modality
            ]
            
            if modality_context:
                relevant_context['recent_similar'] = modality_context
                relevant_context['patterns'] = self._find_patterns(modality_context)
                
            return relevant_context
            
        except Exception as e:
            self.logger.error(f"Error getting relevant context: {e}")
            return {}
            
    def _update_context(self, result: PerceptionResult):
        """Update context history"""
        try:
            context_entry = {
                'modality': result.modality,
                'perceptions': result.perceptions,
                'confidence': result.confidence_scores,
                'timestamp': time.time()
            }
            
            self.context_history.append(context_entry)
            
            # Keep only recent context
            max_history = 1000
            if len(self.context_history) > max_history:
                self.context_history = self.context_history[-max_history:]
                
        except Exception as e:
            self.logger.error(f"Error updating context: {e}")
            
    def _find_patterns(self, context_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Find patterns in context history"""
        try:
            patterns = {}
            
            # Analyze perception patterns
            if context_list:
                perception_keys = set()
                for ctx in context_list:
                    perception_keys.update(ctx.get('perceptions', {}).keys())
                    
                for key in perception_keys:
                    values = [
                        ctx.get('perceptions', {}).get(key)
                        for ctx in context_list
                        if key in ctx.get('perceptions', {})
                    ]
                    if values:
                        patterns[key] = {
                            'frequency': len(values) / len(context_list),
                            'consistency': self._calculate_consistency(values)
                        }
                        
            return patterns
            
        except Exception as e:
            self.logger.error(f"Error finding patterns: {e}")
            return {}
            
    def _calculate_consistency(self, values: List[Any]) -> float:
        """Calculate consistency of values"""
        try:
            if not values:
                return 0.0
                
            if all(isinstance(v, (int, float)) for v in values):
                return 1.0 - np.std(values) / (np.mean(values) + 1e-10)
            elif all(isinstance(v, str) for v in values):
                unique_ratio = len(set(values)) / len(values)
                return 1.0 - unique_ratio
            else:
                return 0.0
                
        except Exception as e:
            self.logger.error(f"Error calculating consistency: {e}")
            return 0.0
            
    def get_perception_result(self, input_id: str) -> Optional[PerceptionResult]:
        """Get result for a specific input"""
        try:
            return self.perception_results.get(input_id)
        except Exception as e:
            self.logger.error(f"Error getting perception result: {e}")
            return None
            
    def clear_old_results(self, max_age: float = 3600):
        """Clear old perception results"""
        try:
            current_time = time.time()
            with self.lock:
                self.perception_results = {
                    input_id: result
                    for input_id, result in self.perception_results.items()
                    if current_time - float(input_id.split('_')[1]) < max_age
                }
        except Exception as e:
            self.logger.error(f"Error clearing old results: {e}")
            
    def shutdown(self):
        """Graceful shutdown"""
        self._shutdown = True
        if hasattr(self, 'perception_thread'):
            self.perception_thread.join()